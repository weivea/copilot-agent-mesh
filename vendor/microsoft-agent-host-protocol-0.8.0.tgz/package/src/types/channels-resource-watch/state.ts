// Generated from types/*.ts — do not edit.
// Regenerate with: npm run generate:typescript

/**
 * Resource-Watch Channel State Types — Per-watch state exposed on
 * `ahp-resource-watch:` channels.
 *
 * @module channels-resource-watch/state
 */

import type { URI } from '../common/state.js';

// ─── Resource Watch Types ────────────────────────────────────────────────────

/**
 * Full state for a single resource watch, returned when a client subscribes
 * to an `ahp-resource-watch:` URI.
 *
 * Watches are otherwise stateless: the watcher exists to deliver
 * {@link ResourceWatchChangedAction} events. The state carries only the
 * descriptor of what is being watched so a re-subscribing client can
 * recover the watch configuration after reconnecting.
 *
 * @category Resource Watch Types
 */
export interface ResourceWatchState {
  /**
   * The URI being watched. For recursive watches this is the root of the
   * subtree; for non-recursive watches this is the single file or
   * directory.
   */
  root: URI;
  /**
   * `true` if the watcher reports changes for descendants of `root`;
   * `false` if it only reports changes to `root` itself (and, when
   * `root` is a directory, its direct children).
   */
  recursive: boolean;
  /**
   * Optional glob patterns or paths relative to `root` to exclude from
   * change reporting.
   */
  excludes?: { items: string[] };
  /**
   * Optional glob patterns or paths relative to `root` to restrict
   * change reporting to. Omit to report every change under `root`
   * subject to `excludes`.
   */
  includes?: { items: string[] };
}

// ─── Resource Change ─────────────────────────────────────────────────────────

/**
 * Discriminant for {@link ResourceChange.type}.
 *
 * @category Resource Watch Types
 */
export const enum ResourceChangeType {
  Added = 'added',
  Updated = 'updated',
  Deleted = 'deleted',
}

/**
 * A single change observed by a resource watcher.
 *
 * @category Resource Watch Types
 */
export interface ResourceChange {
  /** The URI of the resource that changed. */
  uri: URI;
  /** The kind of change observed. */
  type: ResourceChangeType;
}
